import { useState, useEffect } from "react";

export default function UserForm({ initialData = {}, onSubmit, onCancel }) {
  const [nombre, setNombre] = useState("");
  const [email, setEmail] = useState("");
  const [ciudad, setCiudad] = useState("");

  useEffect(() => {
    setNombre(initialData.nombre || "");
    setEmail(initialData.email || "");
    setCiudad(initialData.ciudad || "");
  }, [initialData]);

  const handleSubmit = (e) => {
    e.preventDefault();

    onSubmit({
      nombre,
      email,
      ciudad,
    });

    setNombre("");
    setEmail("");
    setCiudad("");
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Nombre</label>
        <input value={nombre} onChange={(e) => setNombre(e.target.value)} />
      </div>

      <div>
        <label>Email</label>
        <input value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>

      <div>
        <label>Ciudad</label>
        <input value={ciudad} onChange={(e) => setCiudad(e.target.value)} />
      </div>

      <button type="submit">Guardar</button>

      {onCancel && (
        <button type="button" onClick={onCancel} style={{ marginLeft: 10 }}>
          Cancelar
        </button>
      )}
    </form>
  );
}
