export default function UserItem({ user, onEdit, onDelete }) {
  return (
    <li style={{ listStyle: "none", padding: 10, border: "1px solid #ddd", marginBottom: 10 }}>
      <strong>{user.nombre}</strong> - {user.email} - {user.ciudad}

      <div style={{ marginTop: 5 }}>
        <button onClick={() => onEdit(user)} style={{ marginRight: 5 }}>
          Editar
        </button>
        <button onClick={() => onDelete(user.id)}>
          Eliminar
        </button>
      </div>
    </li>
  );
}
