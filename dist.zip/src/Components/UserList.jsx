import UserItem from "./UserItem";

export default function UserList({ users, onEdit, onDelete }) {
  return (
    <ul style={{ padding: 0 }}>
      {users.map((u) => (
        <UserItem
          key={u.id}
          user={u}
          onEdit={onEdit}
          onDelete={onDelete}
        />
      ))}
    </ul>
  );
}
