import { useState } from "react";
import { useUsers } from "../Hooks/useUsers.jsx";
import UserList from "../components/UserList";
import UserForm from "../components/UserForm";

export default function Users() {
  const { users, updateUser, deleteUser } = useUsers();
  const [editingUser, setEditingUser] = useState(null);

  return (
    <div>
      <h2>Lista de Usuarios</h2>

      <UserList
        users={users}
        onEdit={(u) => setEditingUser(u)}
        onDelete={deleteUser}
      />

      {editingUser && (
        <div>
          <h3>Editar usuario</h3>
          <UserForm
            initialData={editingUser}
            onSubmit={(data) => {
              updateUser(editingUser.id, data);
              setEditingUser(null);
            }}
            onCancel={() => setEditingUser(null)}
          />
        </div>
      )}
    </div>
  );
}
