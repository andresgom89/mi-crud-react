import { useNavigate } from "react-router-dom";
import { useUsers } from "../Hooks/useUsers.jsx";
import UserForm from "../components/UserForm";

export default function CreateUser() {
  const { createUser } = useUsers();
  const navigate = useNavigate();

  return (
    <div>
      <h2>Crear nuevo usuario</h2>
      <UserForm
        onSubmit={(data) => {
          createUser(data);
          navigate("/usuarios");
        }}
      />
    </div>
  );
}
