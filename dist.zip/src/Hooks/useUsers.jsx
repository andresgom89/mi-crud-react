import { createContext, useContext, useState, useEffect } from "react";

const UsersContext = createContext();

export function UsersProvider({ children }) {
  const [users, setUsers] = useState([]);

  const apiUrl = "http://localhost:3001/users";

  // GET – obtener usuarios
  useEffect(() => {
    fetch(apiUrl)
      .then((res) => res.json())
      .then((data) => setUsers(data));
  }, []);

  // POST – crear usuario
  const createUser = async (user) => {
    const res = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(user),
    });

    const newUser = await res.json();
    setUsers([...users, newUser]);
  };

  // PUT – actualizar usuario
  const updateUser = async (id, updatedUser) => {
    const res = await fetch(`${apiUrl}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedUser),
    });

    const data = await res.json();

    setUsers(users.map((u) => (u.id === id ? data : u)));
  };

  // DELETE – eliminar usuario
  const deleteUser = async (id) => {
    await fetch(`${apiUrl}/${id}`, { method: "DELETE" });
    setUsers(users.filter((u) => u.id !== id));
  };

  return (
    <UsersContext.Provider value={{ users, createUser, updateUser, deleteUser }}>
      {children}
    </UsersContext.Provider>
  );
}

export function useUsers() {
  return useContext(UsersContext);
}
