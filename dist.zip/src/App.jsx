import { Routes, Route, Link } from "react-router-dom";
import { UsersProvider } from "./Hooks/useUsers.jsx";

import Home from "./pages/Home";
import Users from "./pages/Users";
import CreateUser from "./pages/CreateUser";

function App() {
  return (
    <UsersProvider>
      <nav style={{ padding: 10, borderBottom: "1px solid #ccc" }}>
        <Link to="/" style={{ marginRight: 10 }}>Inicio</Link>
        <Link to="/usuarios" style={{ marginRight: 10 }}>Usuarios</Link>
        <Link to="/crear">Crear Usuario</Link>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/usuarios" element={<Users />} />
        <Route path="/crear" element={<CreateUser />} />
      </Routes>
    </UsersProvider>
  );
}

export default App;
